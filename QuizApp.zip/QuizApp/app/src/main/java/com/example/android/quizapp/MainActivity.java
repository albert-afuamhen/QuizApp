package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    int rightAnswers;
    Button submitBtn;
    Button reset;
    int numberOfCorrectResponse;
    //.............................................................................
    /**
     * This method is called when the Done button is clicked.
     */
    final View.OnClickListener submitBtnOnClickListener = new View.OnClickListener() {

        public void onClick(final View v) {

            //Hide soft keyboard when the user taps the Submit btn
            InputMethodManager inputManager = (InputMethodManager) getSystemService(
                    Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(
                    (null == getCurrentFocus()) ? null : getCurrentFocus().getWindowToken(),
                    InputMethodManager.HIDE_NOT_ALWAYS);

            //CalculateQuizResults method implements the call to the Questions method
            calculateQuizResults();
            //inputted Full is stored in the full_name string
            EditText full_name = findViewById(R.id.enter_full_Name);
            String enter_full_name = full_name.getText().toString();
            //Show a Toast
            String toastString;

            if (rightAnswers == 0) {
                toastString = getString(R.string.oopsToast1) + getString(R.string.oopsToast2);

            } else if (rightAnswers == 100) {
                toastString = getString(R.string.wowToast1) + enter_full_name + getString(R.string.wowToast2) + " " + numberOfCorrectResponse + " " + getString(R.string.numberOfCorrectResponse);

            } else {
                toastString = enter_full_name + "  " + getString(R.string.toast1) + getString(R.string.toast2) + " "
                        + rightAnswers + " " + getString(R.string.toast3) + " " + getString(R.string.wowToast2) + " " + numberOfCorrectResponse + " " + getString(R.string.numberOfCorrectResponse);
            }

            Toast toast = Toast.makeText(MainActivity.this, toastString, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();


            //Avoid double submission
            rightAnswers = 0;
            // initialize value
            numberOfCorrectResponse = 0;


        }
    };

    /**
     * This method is called when the Start Over button is tapped.
     */
    private View.OnClickListener startOverBtnOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
    };

    //........................................................................
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Prevents showing soft keyboard on resume
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        TextView briefIntro = findViewById(R.id.introTextView);
        briefIntro.setTypeface(null, Typeface.BOLD);

        submitBtn = findViewById(R.id.submitBtn);
        reset = findViewById(R.id.startOverBtn);

        submitBtn.setOnClickListener(submitBtnOnClickListener);
        reset.setOnClickListener(startOverBtnOnClickListener);
    }

    private void Question1() {
        RadioButton q1_OptionA = findViewById(R.id.q1_optionA);
        boolean q1_OptionAIsChecked = q1_OptionA.isChecked();
        if (q1_OptionAIsChecked) {
            rightAnswers = rightAnswers + 5;
            numberOfCorrectResponse++;
        }

    }

    private void Question2() {
        RadioButton q2_optionD = findViewById(R.id.q2_optionD);
        boolean q2_optionDIsChecked = q2_optionD.isChecked();

        if (q2_optionDIsChecked) {
            rightAnswers = rightAnswers + 20;
            numberOfCorrectResponse++;
        }

    }

    private void Question3() {
        CheckBox q3_optionA = findViewById(R.id.q3_optionA);
        CheckBox q3_optionB = findViewById(R.id.q3_optionB);
        CheckBox q3_optionC = findViewById(R.id.q3_optionC);
        CheckBox q3_optionD = findViewById(R.id.q3_optionD);
        boolean q3_optionAIsChecked = q3_optionA.isChecked();
        boolean q3_optionBIsChecked = q3_optionB.isChecked();
        boolean q3_optionCIsChecked = q3_optionC.isChecked();
        boolean q3_optionDIsChecked = q3_optionD.isChecked();

        if (q3_optionAIsChecked && q3_optionBIsChecked && !q3_optionCIsChecked
                && !q3_optionDIsChecked) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }
    }

    private void Question4() {
        CheckBox q4_optionA = findViewById(R.id.q4_optionA);
        CheckBox q4_optionB = findViewById(R.id.q4_optionB);
        CheckBox q4_optionC = findViewById(R.id.q4_optionC);
        CheckBox q4_optionD = findViewById(R.id.q4_optionD);
        boolean q4_optionAIsChecked = q4_optionA.isChecked();
        boolean q4_optionBIsChecked = q4_optionB.isChecked();
        boolean q4_optionCIsChecked = q4_optionC.isChecked();
        boolean q4_optionDIsChecked = q4_optionD.isChecked();
        if (q4_optionCIsChecked && !q4_optionBIsChecked && !q4_optionAIsChecked
                && !q4_optionDIsChecked) {
            rightAnswers = rightAnswers + 5;
            numberOfCorrectResponse++;
        }

    }

    private void Question5() {
        RadioButton q5_optionA = findViewById(R.id.q5_optionA);
        boolean q5_optionAIsChecked = q5_optionA.isChecked();
        if (q5_optionAIsChecked) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }

    }

    private void Question6() {
        RadioButton q6_optionB = findViewById(R.id.q6_optionB);
        boolean q6_optionBIsChecked = q6_optionB.isChecked();
        if (q6_optionBIsChecked) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }

    }

    private void Question7() {
        RadioButton q7_optionA = findViewById(R.id.q7_optionA);
        boolean q7_optionAIsChecked = q7_optionA.isChecked();
        if (q7_optionAIsChecked) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }

    }

    private void Question8() {
        //receive text input convert it to string
        EditText q8_Edit_Text_Box = findViewById(R.id.question8_editTextBox);
        String q8_response = q8_Edit_Text_Box.getText().toString().toLowerCase();
        String q8_rightResponse = getString(R.string.q8_right_Response);
//compare input with store right response
        if (q8_response.equals(q8_rightResponse)) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }


    }

    private void Question9() {
        //receive text input convert it to string
        EditText q9_Edit_Text_Box = findViewById(R.id.question9_EditTextBox);
        String q9_response = q9_Edit_Text_Box.getText().toString().toLowerCase();
        String q9_rightResponse = getString(R.string.q8_right_Response);
//compare input with store right response
        if (q9_response.equals(q9_rightResponse)) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }

    }

    private void Question10() {
        RadioButton q10_optionA = findViewById(R.id.q10_optionA);
        boolean q10_optionAIsChecked = q10_optionA.isChecked();
        if (q10_optionAIsChecked) {
            rightAnswers = rightAnswers + 10;
            numberOfCorrectResponse++;
        }

    }

    private void calculateQuizResults() {
        Question1();
        Question2();
        Question3();
        Question4();
        Question5();
        Question6();
        Question7();
        Question8();
        Question9();
        Question10();
    }


}
